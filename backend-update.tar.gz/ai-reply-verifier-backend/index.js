import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import Redis from 'ioredis';

// 获取当前文件的目录
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// 导入路由
import verifyRouter from './api/verify.js';
import accountsRouter from './api/admin/accounts.js';
import licensesRouter from './api/admin/licenses.js';
import loginRouter from './api/admin/login.js';
import logsRouter from './api/admin/logs.js';
import dashboardRouter from './api/admin/dashboard.js';
import resetPasswordRouter from './api/admin/reset-password.js';

const app = express();
const port = process.env.PORT || 3001;
const redis = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');

// 中间件
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json());

// --- 新版后台前端静态文件 ---
const adminPath = path.join(__dirname, 'public', 'admin');
console.log(`Serving admin frontend from: ${adminPath}`);
app.use('/admin', express.static(adminPath));

// --- API 路由 ---
console.log('--- Loading API routes ---');

// 验证路由
app.use('/api/verify', verifyRouter);

// Admin 路由
app.use('/api/admin/accounts', accountsRouter);
app.use('/api/admin/licenses', licensesRouter);
app.use('/api/admin/login', loginRouter);
app.use('/api/admin/logs', logsRouter);
app.use('/api/admin/dashboard', dashboardRouter);
app.use('/api/admin/reset-password', resetPasswordRouter);

console.log('--- API routes loaded ---');

// --- 后台页面路由处理 ---
app.get('/admin', (req, res) => {
  res.redirect('/admin/');
});

// 捕获所有 /admin/ 下的路由，确保刷新页面不报 404
app.get('/admin/*', (req, res) => {
  res.sendFile(path.join(adminPath, 'index.html'));
});

// --- 数据初始化函数 ---
async function initializeData() {
  try {
    const licenseCount = await redis.hlen('licenses');
    if (licenseCount === 0) {
      console.log('未发现任何授权码，正在创建一个默认示例授权码...');
      const defaultLicense = {
        hotelName: "默认示例酒店",
        startDate: "2024-01-01",
        expiryDate: "2099-12-31",
        createdBy: "admin",
        createdTime: new Date().toISOString(),
        activations: []
      };
      await redis.hset('licenses', 'DEFAULT-KEY-123', JSON.stringify(defaultLicense));
      console.log('默认示例授权码创建成功。');
    } else {
      console.log(`发现 ${licenseCount} 个授权码，无需初始化。`);
    }
  } catch (error) {
    console.error('数据初始化检查失败:', error);
  }
}

// 错误处理中间件
app.use((err, req, res, next) => {
  console.error('Error:', err.stack);
  if (err.name === 'UnauthorizedError') {
    return res.status(401).json({ error: '未登录或token无效' });
  }
  res.status(500).json({ error: 'Something broke!' });
});

// 启动服务器
initializeData().then(() => {
  app.listen(port, () => {
    console.log(`Server is running successfully on http://localhost:${port}`);
  });
}); 