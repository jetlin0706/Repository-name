import express from 'express';
import Redis from 'ioredis';
const router = express.Router();

// 创建 Redis 客户端
const redis = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');

// 验证许可证
router.post('/', async (req, res) => {
  try {
    const { licenseKey } = req.body;

    if (!licenseKey) {
      return res.status(400).json({ valid: false, message: 'License key is required' });
    }

    // 硬编码授权码用于测试
    if (licenseKey === 'JD-FIRST-KEY') {
      return res.status(200).json({ valid: true, message: 'License verified successfully.' });
    }

    const rawLicenseData = await redis.hget('licenses', licenseKey);

    if (!rawLicenseData) {
      return res.status(200).json({ valid: false, message: 'Invalid license key.' });
    }
    
    let licenseData;
    try {
      licenseData = JSON.parse(rawLicenseData);
    } catch (e) {
      console.error('Failed to parse license data, raw data:', rawLicenseData, e);
      return res.status(500).json({ valid: false, message: 'An internal server error occurred due to corrupted license data.' });
    }

    const { expiryDate } = licenseData; 
    const now = new Date();
    const expiry = new Date(expiryDate);

    if (now.getTime() > expiry.getTime()) {
      return res.status(200).json({ valid: false, message: 'License has expired.' });
    }

    // 记录激活信息
    const ip = req.ip || req.connection.remoteAddress;
    if (!Array.isArray(licenseData.activations)) {
      licenseData.activations = [];
    }
    licenseData.activations.push({
      ip: ip || 'Unknown',
      timestamp: new Date().toISOString()
    });

    await redis.hset('licenses', licenseKey, JSON.stringify(licenseData));

    return res.status(200).json({ valid: true, message: 'License verified successfully.' });
  } catch (error) {
    console.error('Error in verify API:', error);
    return res.status(500).json({ valid: false, message: 'An internal server error occurred.' });
  }
});

export default router; 