import express from 'express';
import Redis from 'ioredis';
import { authMiddleware } from '../middleware/auth.js'; // 统一认证

const router = express.Router();
const redis = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');

// 获取指定时间段的开始时间
function getPeriodStartDate(period = 'month') {
    const now = new Date();
    now.setHours(now.getHours() + 8); // 修正为东八区时间
    const startDate = new Date(now);

    switch (period) {
        case 'today': // 增加 'today' 周期
            startDate.setHours(0, 0, 0, 0);
            break;
        case 'week':
            const day = startDate.getDay() || 7;
            startDate.setDate(startDate.getDate() - day + 1);
            startDate.setHours(0, 0, 0, 0);
            break;
        case 'month':
            startDate.setDate(1);
            startDate.setHours(0, 0, 0, 0);
            break;
        case 'year':
            startDate.setMonth(0, 1);
            startDate.setHours(0, 0, 0, 0);
            break;
        case 'all':
        default:
            return null;
    }

    return startDate;
}

router.get('/', authMiddleware, async (req, res) => {
    try {
        const user = req.user;
        const period = req.query.period || 'month';
        const periodStartDate = getPeriodStartDate(period);
        const now = new Date();

        const allLicensesRaw = await redis.hgetall('licenses');
        let licenseArray = Object.values(allLicensesRaw).map(val => {
            try { return JSON.parse(val); } catch { return null; }
        }).filter(Boolean);

        if (user.role !== 'admin') {
            licenseArray = licenseArray.filter(l => l.createdBy === user.username);
        }

        const total = licenseArray.length;
        const active = licenseArray.filter(l => new Date(l.expiryDate) > now).length;
        
        const todayStartDate = getPeriodStartDate('today');
        const todayActivations = licenseArray.reduce((count, license) => {
            return count + (license.activations || []).filter(act => 
                act.timestamp && new Date(act.timestamp) >= todayStartDate
            ).length;
        }, 0);

        let agentStats = [];
        if (user.role === 'admin') {
            const accountKeys = await redis.keys('account:*');
            const agents = [];
            for (const key of accountKeys) {
                const raw = await redis.get(key);
                if (!raw) continue;
                try {
                    const acc = JSON.parse(raw);
                    if (acc.role === 'agent') {
                        agents.push({ username: acc.username, name: acc.name });
                    }
                } catch { continue; }
            }
             // 添加超级管理员自己
            agents.push({ username: 'admin', name: '超级管理员' });

            agentStats = agents.map(agent => {
                const agentLicenses = licenseArray.filter(l => l.createdBy === agent.username);
                const currentPeriodLicenses = periodStartDate 
                    ? agentLicenses.filter(l => new Date(l.createdTime) >= periodStartDate)
                    : agentLicenses;
                
                return {
                    username: agent.username,
                    name: agent.name,
                    licenseCount: agentLicenses.length,
                    activeCount: agentLicenses.filter(l => new Date(l.expiryDate) > now).length,
                    periodActivations: currentPeriodLicenses.length,
                    trend: 0 
                };
            });
        }
        
        return res.status(200).json({
            total,
            active,
            todayActivations,
            period,
            agentStats
        });

    } catch (error) {
        console.error('获取看板数据失败:', error);
        return res.status(500).json({ message: '服务器内部错误' });
    }
});

export default router; 