import express from 'express';
import Redis from 'ioredis';
import { authMiddleware } from '../middleware/auth.js'; // 统一认证

const router = express.Router();
const redis = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');
const LOG_KEY = 'logs';
const LOG_MAX = 1000; // 最多保留1000条

// 写入日志
router.post('/', authMiddleware, async (req, res) => {
  try {
    const { type, detail } = req.body;
    if (!type) {
      return res.status(400).json({ error: '缺少type' });
    }

    const log = {
      username: req.user.username,
      role: req.user.role,
      type,
      detail: detail || '',
      time: new Date().toISOString()
    };

    await redis.lpush(LOG_KEY, JSON.stringify(log));
    await redis.ltrim(LOG_KEY, 0, LOG_MAX - 1); // 保留最新1000条
    return res.status(200).json({ message: '日志写入成功' });
  } catch (error) {
    console.error('写入日志失败:', error);
    return res.status(500).json({ error: '服务器内部错误' });
  }
});

// 查询日志
router.get('/', authMiddleware, async (req, res) => {
  try {
    // 分页查询日志
    const { page = 1, pageSize = 20 } = req.query;
    const start = (parseInt(page) - 1) * parseInt(pageSize);
    const end = start + parseInt(pageSize) - 1;
    
    const logsRaw = await redis.lrange(LOG_KEY, start, end);
    let logs = logsRaw.map(str => { try { return JSON.parse(str); } catch { return null; } }).filter(Boolean);
    
    // 代理商只看自己
    if (req.user.role !== 'admin') {
      logs = logs.filter(l => l.username === req.user.username);
    }
    
    return res.status(200).json({ logs });
  } catch (error) {
    console.error('查询日志失败:', error);
    return res.status(500).json({ error: '服务器内部错误' });
  }
});

export default router; 