import express from 'express';
import Redis from 'ioredis';
import bcrypt from 'bcryptjs';
import { authMiddleware, adminMiddleware } from '../middleware/auth.js';

const router = express.Router();
const redis = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');

// 管理员重置任何用户密码
router.post('/', authMiddleware, adminMiddleware, async (req, res) => {
  const { username, newPassword } = req.body;

  if (!username || !newPassword) {
    return res.status(400).json({ message: '用户名和新密码不能为空' });
  }

  try {
    const accountKey = `account:${username}`;
    const userRaw = await redis.get(accountKey);

    if (!userRaw) {
      return res.status(404).json({ message: '账号不存在' });
    }

    const user = JSON.parse(userRaw);
    user.passwordHash = await bcrypt.hash(newPassword, 10);

    await redis.set(accountKey, JSON.stringify(user));

    console.log(`管理员 ${req.user.username} 重置了用户 ${username} 的密码。`);
    return res.status(200).json({ message: `用户 ${username} 的密码已成功重置` });

  } catch (error) {
    console.error('重置密码失败:', error);
    return res.status(500).json({ message: '服务器内部错误' });
  }
});

export default router; 