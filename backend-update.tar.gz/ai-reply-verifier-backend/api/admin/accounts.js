// /api/admin/accounts
import express from 'express';
import Redis from 'ioredis';
import bcrypt from 'bcryptjs';
import { authMiddleware, adminMiddleware } from '../middleware/auth.js'; // 统一认证

const router = express.Router();
const redis = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');

// 日志写入工具
async function writeLog(user, type, detail) {
  await redis.lpush('logs', JSON.stringify({
    username: user.username,
    role: user.role,
    type,
    detail,
    time: new Date().toISOString()
  }));
  await redis.ltrim('logs', 0, 999);
}

// 获取当前用户信息
router.get('/me', authMiddleware, (req, res) => {
  console.log('返回当前用户信息:', req.user);
  return res.status(200).json({ 
    user: { 
      username: req.user.username, 
      role: req.user.role, 
      name: req.user.name 
    } 
  });
});

// 获取所有账号
router.get('/', authMiddleware, adminMiddleware, async (req, res) => {
  console.log('获取账号列表，请求用户:', req.user.username);
  
  // 始终添加admin账户到列表中
  const accounts = [
    {
      username: 'admin',
      name: '超级管理员',
      role: 'admin',
      createdAt: '—'
    }
  ];
  
  try {
    const keys = await redis.keys('account:*');
    console.log(`找到${keys.length}个账号记录，keys:`, keys);
    
    for (const key of keys) {
      const raw = await redis.get(key);
      console.log(`获取到账号数据 ${key}:`, raw);
      
      if (!raw) {
        console.log(`账号 ${key} 数据为空，跳过`);
        continue;
      }
      
      try { 
        const acc = typeof raw === 'string' ? JSON.parse(raw) : raw;
        console.log(`解析后的账号数据:`, acc);
        
        if (acc.username !== 'admin') {
          accounts.push({ 
            username: acc.username, 
            name: acc.name, 
            role: acc.role, 
            createdAt: acc.createdAt 
          });
          console.log(`添加账号 ${acc.username} 到列表`);
        }
      } catch (e) { 
        console.error(`解析账号数据出错 ${key}:`, e);
        continue; 
      }
    }
    
    console.log(`返回${accounts.length}个账号:`, accounts);
    return res.status(200).json({ accounts });
  } catch (e) {
    console.error('获取账号列表出错:', e);
    return res.status(200).json({ accounts }); // 即使出错，依然返回admin账号
  }
});

// 创建新账号
router.post('/', authMiddleware, adminMiddleware, async (req, res) => {
  const { username, password, name } = req.body;
  console.log(`尝试添加账号: ${username}, 名称: ${name}, 操作者: ${req.user.username}`);
  
  if (!username || !password || !name) {
    const missing = [];
    if (!username) missing.push('用户名');
    if (!password) missing.push('密码');
    if (!name) missing.push('名称');
    return res.status(400).json({ error: `${missing.join('、')}不能为空` });
  }
  
  try {
    const exists = await redis.get(`account:${username}`);
    if (exists) {
      console.error(`添加账号错误: 账号 ${username} 已存在`);
      return res.status(409).json({ error: '账号已存在' });
    }
    
    const passwordHash = await bcrypt.hash(password, 10);
    const verifyHash = await bcrypt.compare(password, passwordHash);
    if (!verifyHash) {
      throw new Error('密码哈希验证失败');
    }
    
    const acc = { 
      username, 
      passwordHash, 
      role: 'agent', 
      name, 
      createdAt: new Date().toISOString() 
    };
    
    await redis.set(`account:${username}`, JSON.stringify(acc));
    await writeLog(req.user, 'add_account', `添加合作伙伴:${username}(${name})`);
    
    return res.status(201).json({ message: '创建成功' });
  } catch (error) {
    console.error(`添加账号过程中出错:`, error);
    return res.status(500).json({ error: '创建账号失败，请稍后重试' });
  }
});

// 删除账号
router.delete('/:username', authMiddleware, adminMiddleware, async (req, res) => {
  const { username } = req.params;
  
  if (!username) {
    return res.status(400).json({ message: '缺少账号' });
  }
  
  console.log(`尝试删除账号: ${username}, 操作者: ${req.user.username}`);
  
  if (username === 'admin') {
    return res.status(403).json({ message: '不能删除超级管理员' });
  }
  
  try {
    const accountExists = await redis.get(`account:${username}`);
    if (!accountExists) {
      return res.status(404).json({ message: '账号不存在' });
    }
    
    await redis.del(`account:${username}`);
    await writeLog(req.user, 'delete_account', `删除账号:${username}`);
    
    return res.status(200).json({ message: '删除成功' });
  } catch (error) {
    console.error(`删除账号过程中出错:`, error);
    return res.status(500).json({ message: '删除账号失败，请稍后重试' });
  }
});

export default router; 