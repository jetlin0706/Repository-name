// /api/admin/login
import express from 'express';
import Redis from 'ioredis';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

const router = express.Router();
const redis = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');
const JWT_SECRET = process.env.JWT_SECRET || 'ai-reply-secret';

// 登录路由
router.post('/', async (req, res) => {
  try {
    const { username, password } = req.body;
    console.log(`Login attempt for username: ${username}`);

    if (!username || !password) {
      console.error(`Login error: Missing credentials - username: ${!!username}, password: ${!!password}`);
      return res.status(400).json({ error: '用户名和密码不能为空' });
    }
    
    // 硬编码的测试账号 - 仅用于开发环境
    if (username === 'admin' && password === 'Aa123456.') {
      console.log('使用硬编码的测试账号登录成功');
      const testUser = {
        username: 'admin',
        role: 'admin',
        name: '超级管理员'
      };
      const token = jwt.sign(testUser, JWT_SECRET, { expiresIn: '2d' });
      return res.status(200).json({ token, user: testUser });
    }

    const userRaw = await redis.get(`account:${username}`);
    if (!userRaw) {
      console.error(`Login error: Account not found for username: ${username}`);
      return res.status(401).json({ error: '账号不存在' });
    }

    let user;
    try {
      user = typeof userRaw === 'string' ? JSON.parse(userRaw) : userRaw;
    } catch (error) {
      console.error(`Login error: Failed to parse user data for ${username}`, error);
      return res.status(500).json({ error: '账号数据异常' });
    }

    // 检查passwordHash是否存在
    if (!user.passwordHash) {
      console.error(`Login error: Password hash is missing for user: ${username}`);
      return res.status(500).json({ error: '账号数据异常，请联系管理员' });
    }

    try {
      const match = await bcrypt.compare(password, user.passwordHash);
      if (!match) {
        console.error(`Login error: Password mismatch for user: ${username}`);
        return res.status(401).json({ error: '密码错误' });
      }
    } catch (error) {
      console.error(`Login error: bcrypt compare failed for user: ${username}`, error);
      return res.status(500).json({ error: '登录验证失败，请联系管理员' });
    }

    // 生成JWT
    const token = jwt.sign({ username: user.username, role: user.role, name: user.name }, JWT_SECRET, { expiresIn: '2d' });
    console.log(`Login successful for user: ${username}, role: ${user.role}`);
    res.status(200).json({ token, user: { username: user.username, role: user.role, name: user.name } });
  } catch (error) {
    console.error('Unexpected error in login handler:', error);
    res.status(500).json({ error: '服务器内部错误' });
  }
});

export default router; 