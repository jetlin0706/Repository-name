import express from 'express';
import Redis from 'ioredis';
import { authMiddleware, adminMiddleware } from '../middleware/auth.js'; // 统一认证

const router = express.Router();
const redis = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');
const JWT_SECRET = process.env.JWT_SECRET || 'ai-reply-secret';

// 日志写入工具
async function writeLog(user, type, detail) {
  await redis.lpush('logs', JSON.stringify({
    username: user.username,
    role: user.role,
    type,
    detail,
    time: new Date().toISOString()
  }));
  await redis.ltrim('logs', 0, 999);
}

// 获取用户名称
async function getUserName(username) {
  if (username === 'admin') return '超级管理员';
  
  try {
    const accountData = await redis.get(`account:${username}`);
    if (!accountData) return username;
    
    const account = typeof accountData === 'string' ? JSON.parse(accountData) : accountData;
    return account.name || username;
  } catch (error) {
    console.error('获取用户名称失败:', error);
    return username;
  }
}

// 获取许可证列表
router.get('/', authMiddleware, async (req, res) => {
  try {
    // 管理员查全部，代理商查自己
    const all = await redis.hgetall('licenses');
    const result = {};
    
    // 获取所有合作伙伴的名称映射
    const accountKeys = await redis.keys('account:*');
    const accountMap = {};
    
    for (const key of accountKeys) {
      const username = key.replace('account:', '');
      const accountData = await redis.get(key);
      if (!accountData) continue;
      
      try {
        const account = typeof accountData === 'string' ? JSON.parse(accountData) : accountData;
        accountMap[username] = account.name || username;
      } catch (error) {
        console.error(`解析账号数据失败: ${key}`, error);
      }
    }
    
    for (const key in all) {
      let lic;
      try { lic = typeof all[key] === 'string' ? JSON.parse(all[key]) : all[key]; } catch { continue; }
      if (req.user.role === 'admin' || lic.createdBy === req.user.username) {
        // 添加创建人名称
        if (lic.createdBy) {
          lic.creatorName = lic.createdBy === 'admin' ? '超级管理员' : accountMap[lic.createdBy] || lic.createdBy;
        }
        result[key] = lic;
      }
    }
    return res.status(200).json(result);
  } catch (error) {
    console.error('获取许可证列表失败:', error);
    return res.status(500).json({ message: '服务器内部错误' });
  }
});

// 创建/更新许可证
router.post('/', authMiddleware, async (req, res) => {
  try {
    const { licenseKey, hotelName, startDate, expiryDate } = req.body;
    if (!licenseKey || !hotelName || !expiryDate || !startDate) {
      return res.status(400).json({ message: '缺少字段' });
    }

    const existingRaw = await redis.hget('licenses', licenseKey);
    let activations = [];
    let createdBy = req.user.username;
    let createdTime = new Date().toISOString();
    
    if (existingRaw) {
      let existing;
      try { existing = typeof existingRaw === 'string' ? JSON.parse(existingRaw) : existingRaw; } catch { existing = {}; }
      activations = existing.activations || [];
      createdBy = existing.createdBy || req.user.username;
      createdTime = existing.createdTime || createdTime;
      // 代理商只能更新自己创建的
      if (req.user.role !== 'admin' && createdBy !== req.user.username) {
        return res.status(403).json({ message: '无权修改他人激活码' });
      }
    }
    
    const licenseData = { 
      hotelName, 
      startDate, 
      expiryDate, 
      activations, 
      createdBy,
      createdTime
    };
    
    await redis.hset('licenses', licenseKey, JSON.stringify(licenseData));
    await writeLog(req.user, existingRaw ? 'update_license' : 'add_license', `${existingRaw ? '更新' : '添加'}激活码:${licenseKey}(${hotelName})`);
    return res.status(200).json({ message: '保存成功' });
  } catch (error) {
    console.error('创建/更新许可证失败:', error);
    return res.status(500).json({ message: '服务器内部错误' });
  }
});

// 删除许可证
router.delete('/', authMiddleware, async (req, res) => {
  try {
    const { licenseKey } = req.body;
    if (!licenseKey) {
      return res.status(400).json({ message: '缺少licenseKey' });
    }

    // 先检查授权码是否存在
    const raw = await redis.hget('licenses', licenseKey);
    if (!raw) {
      return res.status(404).json({ message: '激活码不存在' });
    }

    let lic;
    try { 
      lic = typeof raw === 'string' ? JSON.parse(raw) : raw; 
    } catch (e) { 
      console.error('解析授权码数据失败:', e);
      lic = {}; 
    }
    
    // 检查权限
    if (req.user.role !== 'admin' && lic.createdBy !== req.user.username) {
      return res.status(403).json({ message: '无权删除他人激活码' });
    }
    
    // 执行删除
    await redis.hdel('licenses', licenseKey);
    await writeLog(req.user, 'delete_license', `删除激活码:${licenseKey}(${lic.hotelName || ''})`);
    return res.status(200).json({ message: '删除成功', license: lic });
  } catch (error) {
    console.error('删除许可证失败:', error);
    return res.status(500).json({ message: '服务器内部错误' });
  }
});

export default router; 