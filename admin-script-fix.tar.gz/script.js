document.addEventListener('DOMContentLoaded', () => {
    console.log('初始化管理后台脚本...');
    
    // 使用相对路径，确保API路径正确
    const apiBaseUrl = '/api/admin';
    
    let password = null;
    let allLicenses = {}; // Cache for licenses
    let isAuthenticated = false; // 添加认证状态标志
    let currentUser = null;
    let jwtToken = localStorage.getItem('token');
    
    // 新版多角色登录相关变量
    const loginContainer = document.getElementById('loginContainer');
    let loginUsername = document.getElementById('loginUsername');
    let loginPassword = document.getElementById('loginPassword');
    let loginBtn = document.getElementById('loginBtn');
    let loginMessage = document.getElementById('loginMessage');
    const userInfo = document.getElementById('userInfo');
    const welcomeText = document.getElementById('welcomeText');
    const logoutBtn = document.getElementById('logoutBtn');

    // DOM Elements
    const licenseForm = document.getElementById('licenseForm');
    const licensesTableBody = document.querySelector('#licensesTable tbody');
    const generateKeyBtn = document.getElementById('generateKeyBtn');
    const licenseKeyInput = document.getElementById('licenseKey');
    const startDateInput = document.getElementById('startDate');
    const expiryDateInput = document.getElementById('expiryDate');
    const hotelNameInput = document.getElementById('hotelName');
    const accountsTable = document.querySelector('#accountsTable tbody');
    const addAccountForm = document.getElementById('addAccountForm');
    const newAccountUsername = document.getElementById('newAccountUsername');
    const newAccountName = document.getElementById('newAccountName');
    const newAccountPassword = document.getElementById('newAccountPassword');

    // Dashboard Elements
    const totalLicensesEl = document.getElementById('totalLicenses');
    const activeLicensesEl = document.getElementById('activeLicenses');
    const todayActivationsEl = document.getElementById('todayActivations');
    let agentStatsContainer = document.getElementById('agentStatsContainer');
    if (!agentStatsContainer) {
        agentStatsContainer = document.createElement('div');
        agentStatsContainer.id = 'agentStatsContainer';
        agentStatsContainer.style.marginTop = '16px';
        document.getElementById('dashboard').appendChild(agentStatsContainer);
    }

    // 获取主容器
    const mainContainer = document.querySelector('.container');
    // 创建旧版登录容器的引用
    let oldLoginContainer = null;

    // 立即检查登录状态
    checkLoginStatus();
    
    // 配置API基础URL
    console.log('当前API基础URL:', apiBaseUrl);

    async function checkLoginStatus() {
        jwtToken = localStorage.getItem('token'); // 每次检查都重新获取
        if (!jwtToken) {
            console.log('未检测到登录token，显示登录表单');
            showLoginForm();
            return;
        }

        try {
            const response = await apiFetch('/api/admin/accounts/me'); // 使用新的/me端点
            if (response.ok) {
                const data = await response.json();
                console.log('Token有效，用户信息:', data.user);
                await loginAndInit(jwtToken, data.user);
            } else {
                throw new Error('Token验证失败或已过期');
            }
        } catch (error) {
            console.error('Token验证出错:', error);
            logout();
        }
    }

    // 更新用户信息显示
    function updateUserInfo() {
        if (currentUser && userInfo && welcomeText) {
            userInfo.style.display = 'flex';
            welcomeText.textContent = `欢迎, ${currentUser.name || currentUser.username}`;
        }
    }

    // 登出函数
    function logout() {
        localStorage.removeItem('token');
        jwtToken = null;
        currentUser = null;
        isAuthenticated = false;
        // 刷新页面以确保所有状态都重置
        window.location.reload();
    }

    // 添加登出按钮事件监听
    if (logoutBtn) {
        logoutBtn.addEventListener('click', logout);
    }

    // 隐藏主要内容，显示登录表单
    function showLoginForm() {
        console.log('显示登录表单');
        // 显示内置登录表单
        if (loginContainer) {
            loginContainer.style.display = 'block';
            // 隐藏其他内容
            Array.from(mainContainer.children).forEach(child => {
                if (child !== loginContainer) {
                    child.style.display = 'none';
                }
            });
            if (loginUsername) loginUsername.focus();
            return;
        }
        
        // 旧版兼容，使用创建的登录表单
        if (!oldLoginContainer) {
            oldLoginContainer = document.createElement('div');
            oldLoginContainer.className = 'login-container card';
            oldLoginContainer.innerHTML = `
                <h2>管理员登录</h2>
                <div class="form-group">
                    <label for="adminPassword">管理员密码</label>
                    <input type="password" id="adminPassword" placeholder="请输入管理员密码">
                </div>
                <button id="loginBtn">登录</button>
                <p id="loginMessage" class="error-message"></p>
            `;
            mainContainer.prepend(oldLoginContainer);
        } else {
            oldLoginContainer.style.display = 'block';
        }
        
        // 隐藏所有子元素
        Array.from(mainContainer.children).forEach(child => {
            if (child !== oldLoginContainer) {
                child.style.display = 'none';
            }
        });
        
        const adminPassword = document.getElementById('adminPassword');
        if (adminPassword) adminPassword.focus();
    }
    
    // 显示主要内容，隐藏登录表单
    function showMainContent() {
        console.log('显示主内容');
        if (loginContainer) {
            loginContainer.style.display = 'none';
        }
        
        if (oldLoginContainer) {
            oldLoginContainer.style.display = 'none';
        }
        
        Array.from(mainContainer.children).forEach(child => {
            if (child !== loginContainer && child !== oldLoginContainer) {
                child.style.display = '';
            }
        });
    }

    function getAuthHeaders() {
        // 只使用JWT Token
        const token = localStorage.getItem('token');
        if (token) {
            return { 'Authorization': `Bearer ${token}` };
        }
        return {};
    }

    // [最终修复] 封装fetch，确保认证头在所有情况下都正确
    async function apiFetch(url, options = {}) {
        try {
            const config = { 
                ...options,
                headers: {
                    'Content-Type': 'application/json',
                    ...getAuthHeaders(),
                    ...options.headers
                }
            };
            
            // 确保DELETE请求也有正确的请求体格式
            if (config.method === 'DELETE' && config.body && typeof config.body === 'string') {
                try {
                    JSON.parse(config.body); // 验证是否为有效的JSON
                } catch (e) {
                    config.body = JSON.stringify(config.body);
                }
            }
            
            const resp = await fetch(url, config);
            
            if (resp.status === 401) {
                logout(); // 认证失败则登出
                throw new Error('认证失败，请重新登录');
            }
            return resp;
        } catch (error) {
            console.error(`API请求失败: ${url}`, error);
            throw error;
        }
    }

    // 获取仪表盘数据
    async function fetchDashboard() {
        try {
            console.log('获取仪表盘数据...');
            const resp = await apiFetch(`${apiBaseUrl}/dashboard`);
            if (resp.ok) {
                const data = await resp.json();
                console.log('仪表盘数据:', data);
                updateDashboardStats(data);
            }
        } catch (error) {
            console.error('获取仪表盘数据失败:', error);
        }
    }

    async function fetchLicenses() {
        try {
            console.log('正在获取授权码列表...');
            const response = await apiFetch(`${apiBaseUrl}/licenses`);
            if (!response.ok) throw new Error('获取授权码失败');
            
            const licenses = await response.json();
            console.log('获取到的授权码数据:', licenses);
            
            // 保存到全局变量，并使用包含分页和搜索的渲染函数
            allLicenses = licenses;
            renderLicensesWithSearchAndPage(); 
            updateDashboard(licenses);

        } catch (error) {
            console.error('Error fetching licenses:', error);
            licensesTableBody.innerHTML = '<tr><td colspan="9" style="text-align:center;">加载授权码列表失败</td></tr>';
        }
    }

    function renderLicenses(licenses) {
        licensesTableBody.innerHTML = '';
        Object.entries(licenses).forEach(([key, license]) => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td class="license-key" title="${key}">${key}</td>
                <td>${license.hotelName || 'undefined'}</td>
                <td>${license.startDate || 'N/A'}</td>
                <td>${license.expiryDate || ''}</td>
                <td>${isExpired(license.expiryDate) ? '<span class="expired">已过期</span>' : '<span class="valid">有效</span>'}</td>
                <td>${license.activations ? license.activations.length : 0}</td>
                <td>${license.activations && license.activations.length > 0 ? license.activations[license.activations.length - 1].ip : 'N/A'}</td>
                <td>${license.creatorName || 'N/A'}</td>
                <td>
                    <button class="btn btn-primary btn-sm copy-btn" data-key="${key}" data-info="${encodeURIComponent(JSON.stringify({
                        key: key,
                        hotel: license.hotelName,
                        start: license.startDate,
                        expiry: license.expiryDate,
                        status: isExpired(license.expiryDate) ? '已过期' : '有效',
                        activations: license.activations ? license.activations.length : 0,
                        lastIp: license.activations && license.activations.length > 0 ? license.activations[license.activations.length - 1].ip : 'N/A',
                        creator: license.creatorName || 'N/A'
                    }))}">复制</button>
                    <button class="btn btn-warning btn-sm edit-btn">重制</button>
                    <button class="btn btn-danger btn-sm delete-btn">删除</button>
                </td>
            `;

            // 添加复制功能
            const copyBtn = row.querySelector('.copy-btn');
            copyBtn.addEventListener('click', async (e) => {
                e.preventDefault();
                const info = JSON.parse(decodeURIComponent(copyBtn.dataset.info));
                const text = `激活码: ${info.key}
酒店名称: ${info.hotel}
开始时间: ${info.start}
到期时间: ${info.expiry}
状态: ${info.status}
激活次数: ${info.activations}
最近IP: ${info.lastIp}
创建人: ${info.creator}`;
                
                try {
                    if (navigator.clipboard) {
                        await navigator.clipboard.writeText(text);
                        alert('已复制到剪贴板');
                    } else {
                        // 降级方案
                        const textarea = document.createElement('textarea');
                        textarea.value = text;
                        textarea.style.position = 'fixed';  // 避免页面滚动
                        document.body.appendChild(textarea);
                        textarea.focus();
                        textarea.select();
                        const success = document.execCommand('copy');
                        document.body.removeChild(textarea);
                        
                        if (success) {
                            alert('已复制到剪贴板');
                        } else {
                            throw new Error('execCommand复制失败');
                        }
                    }
                } catch (err) {
                    console.error('复制失败:', err);
                    // 降级方案
                    const textarea = document.createElement('textarea');
                    textarea.value = text;
                    document.body.appendChild(textarea);
                    textarea.select();
                    try {
                        document.execCommand('copy');
                        alert('已复制到剪贴板');
                    } catch (e) {
                        console.error('复制失败:', e);
                        alert('复制失败，请手动复制');
                    }
                    document.body.removeChild(textarea);
                }
            });

            // 添加删除功能
            const deleteBtn = row.querySelector('.delete-btn');
            deleteBtn.addEventListener('click', deleteLicense);
            deleteBtn.dataset.key = key;

            // 添加编辑功能
            const editBtn = row.querySelector('.edit-btn');
            editBtn.addEventListener('click', () => {
                licenseKeyInput.value = key;
                hotelNameInput.value = license.hotelName || '';
                startDateInput.value = license.startDate || '';
                expiryDateInput.value = license.expiryDate || '';
                generateKeyBtn.disabled = true;
            });

            licensesTableBody.appendChild(row);
        });
    }
    
    function updateDashboard(licenses) {
        // Ensure licenses is an object before iterating
        if (typeof licenses !== 'object' || licenses === null) {
            console.error("Received non-object data for licenses for dashboard:", licenses);
            totalLicensesEl.textContent = 0;
            activeLicensesEl.textContent = 0;
            todayActivationsEl.textContent = 0;
            agentStatsContainer.innerHTML = '';
            return;
        }

        const licenseArray = Object.values(licenses).map(val => {
            if (typeof val === 'string') {
                try {
                    return JSON.parse(val);
                } catch (e) {
                    console.error('Could not parse license data in dashboard:', val);
                    return null;
                }
            } else if (typeof val === 'object' && val !== null) {
                return val;
            }
            return null;
        }).filter(Boolean); // Filter out nulls from parsing errors
        
        const now = new Date();
        const today = now.toISOString().split('T')[0];

        const total = licenseArray.length;
        const active = licenseArray.filter(l => new Date(l.expiryDate) > now).length;
        
        const todayActivations = licenseArray.reduce((count, license) => {
            const activationsToday = (license.activations || []).filter(act => act.timestamp.startsWith(today)).length;
            return count + activationsToday;
        }, 0);

        totalLicensesEl.textContent = total;
        activeLicensesEl.textContent = active;
        todayActivationsEl.textContent = todayActivations;
        updateDashboardStats({ total, active, todayActivations });
    }

    function updateDashboardStats(data) {
        totalLicensesEl.textContent = data.total || 0;
        activeLicensesEl.textContent = data.active || 0;
        todayActivationsEl.textContent = data.todayActivations || 0;
        // 管理员显示代理商分布
        if (data.agentStats && Array.isArray(data.agentStats) && data.agentStats.length > 0) {
            let html = '<h4 style="margin:8px 0 4px 0;">各代理商授权分布</h4>';
            html += '<table style="width:100%;border-collapse:collapse;text-align:center;">';
            html += '<tr><th>代理商</th><th>激活码数</th><th>有效</th><th>今日激活</th></tr>';
            data.agentStats.forEach(a => {
                html += `<tr><td>${a.name} (${a.username})</td><td>${a.licenseCount}</td><td>${a.activeCount}</td><td>${a.todayActivations}</td></tr>`;
            });
            html += '</table>';
            agentStatsContainer.innerHTML = html;
        } else {
            agentStatsContainer.innerHTML = '';
        }
    }

    async function saveLicense(event) {
        event.preventDefault();
        console.log('保存授权码...');
        
        if (!isAuthenticated) {
            alert('请先登录');
            showLoginForm();
            return;
        }
        
        if (!licenseKeyInput.value.trim()) {
            alert('请输入授权码');
            return;
        }
        
        if (!hotelNameInput.value.trim()) {
            alert('请输入酒店名称');
            return;
        }
        
        // 检查日期是否有效
        if (!startDateInput.value) {
            alert('请选择开始日期');
            return;
        }
        
        if (!expiryDateInput.value) {
            alert('请选择到期日期');
            return;
        }
        
        const licenseData = {
            licenseKey: licenseKeyInput.value.trim(),
            hotelName: hotelNameInput.value.trim(),
            startDate: startDateInput.value,
            expiryDate: expiryDateInput.value
        };

        try {
            console.log('保存授权码数据:', licenseData);
            const response = await apiFetch(`${apiBaseUrl}/licenses`, {
                method: 'POST',
                body: JSON.stringify(licenseData)
            });

            console.log('保存授权码响应状态:', response.status);
            
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(`HTTP error! status: ${response.status}, message: ${errorData.message || 'Unknown error'}`);
            }

            alert('保存成功！');
            licenseForm.reset();
            setDefaultDates();
            fetchLicenses();

        } catch (error) {
            console.error('Error saving license:', error);
            alert(`保存失败: ${error.message}`);
        }
    }

    async function deleteLicense(event) {
        if (!event.target.classList.contains('delete-btn')) return;
        
        if (!isAuthenticated) {
            alert('请先登录');
            showLoginForm();
            return;
        }

        const licenseKey = event.target.dataset.key;
        if (!confirm(`确定要删除授权码 "${licenseKey}" 吗？此操作不可撤销。`)) return;
        
        const cleanLicenseKey = licenseKey.replace(/\*/g, '');

        try {
            const response = await apiFetch(`${apiBaseUrl}/licenses`, {
                method: 'DELETE',
                headers: { ...getAuthHeaders(), 'Content-Type': 'application/json' },
                body: JSON.stringify({ licenseKey: cleanLicenseKey })
            });
            
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

            alert('删除成功！');
            fetchLicenses();

        } catch (error) {
            console.error('Error deleting license:', error);
            alert('删除失败，请查看控制台获取详情。');
        }
    }

    function generateRandomKey() {
        console.log('生成随机授权码');
        const prefix = "HOTEL";
        const randomPart = Math.random().toString(36).substring(2, 10).toUpperCase();
        licenseKeyInput.value = `${prefix}-${randomPart}`;
    }

    function setDefaultDates() {
        console.log('设置默认日期');
        const today = new Date();
        const oneYearLater = new Date(today);
        oneYearLater.setFullYear(today.getFullYear() + 1);
        
        // 格式化日期为YYYY-MM-DD格式
        const formatDate = (date) => {
            const year = date.getFullYear();
            const month = String(date.getMonth() + 1).padStart(2, '0');
            const day = String(date.getDate()).padStart(2, '0');
            return `${year}-${month}-${day}`;
        };
        
        startDateInput.value = formatDate(today);
        expiryDateInput.value = formatDate(oneYearLater);
        
        // 确保日期选择器可用
        startDateInput.type = 'date';
        expiryDateInput.type = 'date';
    }

    async function handleLogin(event) {
        if(event) event.preventDefault();
        const username = loginUsername.value.trim();
        const password = loginPassword.value.trim();

        if (!username || !password) {
            loginMessage.textContent = '用户名和密码不能为空';
            return;
        }

        try {
            const response = await fetch(`${apiBaseUrl}/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password })
            });
            const data = await response.json();
            if (response.ok) {
                await loginAndInit(data.token, data.user);
            } else {
                loginMessage.textContent = data.error || '登录失败';
            }
        } catch (error) {
            loginMessage.textContent = '登录请求失败，请检查网络';
        }
    }
    
    // 登录成功后，拉取dashboard数据
    async function loginAndInit(token, user) {
        if (!token || !user) {
            return logout();
        }

        console.log('登录并初始化, 用户:', user);
        localStorage.setItem('token', token);
        jwtToken = token;
        currentUser = user;
        isAuthenticated = true; // [FIX] Set authentication flag

        showMainContent();
        updateUserInfo();
        
        // 登录后，根据角色更新UI元素的可见性
        updateUIVisibility();

        // 并行加载所有相关数据
        console.log('开始并行加载Dashboard、授权码和账号数据...');
        await Promise.allSettled([
            fetchDashboard(),
            fetchLicenses(),
            fetchAccounts(),
            fetchLogs()
        ]);
        console.log('所有数据加载完成。');
    }
    
    // 初始化表单和按钮
    function initFormAndButtons() {
        console.log('初始化表单和按钮');
        // 移除可能存在的旧事件监听器
        if (licenseForm) {
            licenseForm.removeEventListener('submit', saveLicense);
    licenseForm.addEventListener('submit', saveLicense);
            console.log('表单提交事件已绑定');
        }
        
        if (generateKeyBtn) {
            generateKeyBtn.removeEventListener('click', generateRandomKey);
    generateKeyBtn.addEventListener('click', generateRandomKey);
            console.log('随机生成按钮事件已绑定');
        }
        
        // 绑定表格操作事件
        if (licensesTableBody) {
            // [FIX] 使用事件委托处理按钮点击，并且只绑定一次
            if (!licensesTableBody.dataset.eventsAttached) {
                licensesTableBody.addEventListener('click', async function(event) {
                    const target = event.target;

                    // 复制功能
                    if (target.classList.contains('copy-btn')) {
                        event.preventDefault();
                        const info = JSON.parse(decodeURIComponent(target.dataset.info));
                        const text = `激活码: ${info.key}\n酒店名称: ${info.hotel}\n开始时间: ${info.start}\n到期时间: ${info.expiry}\n状态: ${info.status}\n激活次数: ${info.activations}\n最近IP: ${info.lastIp}\n创建人: ${info.creator}`;
                        
                        try {
                            if (navigator.clipboard && window.isSecureContext) {
                                await navigator.clipboard.writeText(text);
                                target.textContent = '已复制';
                            } else {
                                const textarea = document.createElement('textarea');
                                textarea.value = text;
                                textarea.style.position = 'fixed';
                                document.body.appendChild(textarea);
                                textarea.select();
                                document.execCommand('copy');
                                document.body.removeChild(textarea);
                                target.textContent = '已复制';
                            }
                        } catch (err) {
                            console.error('复制失败:', err);
                            alert('复制失败，请查看控制台');
                        } finally {
                            setTimeout(() => { target.textContent = '复制'; }, 2000);
                        }
                    }

                    // 删除功能
                    if (target.classList.contains('delete-btn')) {
                        if (!isAuthenticated) {
                            alert('请先登录');
                            return;
                        }
                        const licenseKey = target.dataset.key;
                        if (confirm(`确定要删除授权码 "${licenseKey}" 吗？此操作不可撤销。`)) {
                            try {
                                const response = await apiFetch(`${apiBaseUrl}/licenses`, {
                                    method: 'DELETE',
                                    body: JSON.stringify({ licenseKey })
                                });
                                if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
                                alert('删除成功！');
                                fetchLicenses();
                            } catch (error) {
                                console.error('Error deleting license:', error);
                                alert('删除失败，请查看控制台获取详情。');
                            }
                        }
                    }
                    
                    // 编辑功能
                    if (target.classList.contains('edit-btn')) {
                        const licenseKey = target.dataset.key;
                        // 确保 allLicenses 存在并且是对象类型
                        if (typeof allLicenses === 'object' && allLicenses !== null && licenseKey in allLicenses) {
                            const license = allLicenses[licenseKey];
                            licenseKeyInput.value = licenseKey;
                            hotelNameInput.value = license.hotelName || '';
                            startDateInput.value = license.startDate || '';
                            expiryDateInput.value = license.expiryDate || '';
                            generateKeyBtn.disabled = true;
                            licenseKeyInput.readOnly = true;
                        } else {
                            console.error('无法编辑授权码：allLicenses未定义或者不包含指定的key', { licenseKey, allLicenses });
                            alert('无法编辑此授权码，请刷新页面后重试。');
                        }
                    }
                });
                licensesTableBody.dataset.eventsAttached = 'true';
                console.log('表格操作事件已通过事件委托绑定');
            }
        }
        
        // 确保日期选择器可用
        setDefaultDates();
    }
    
    // 初始化
    initFormAndButtons();
    setupLoginForm();
    
    // 检查是否有token，有则尝试自动登录
    if (jwtToken) {
        console.log('检测到token，尝试自动登录');
        // 尝试获取用户信息
        fetch(`${apiBaseUrl}/accounts/me`, {
            headers: { 'Authorization': `Bearer ${jwtToken}` }
        })
        .then(resp => {
            console.log('获取用户信息响应:', resp.status);
            if (!resp.ok) {
                throw new Error('Token无效');
            }
            return resp.json();
        })
        .then(data => {
            console.log('获取到用户信息:', data);
            if (data.user) {
                loginAndInit(jwtToken, data.user);
            } else {
                throw new Error('获取用户信息失败');
            }
        })
        .catch(err => {
            console.error('自动登录失败:', err);
            localStorage.removeItem('token');
            showLoginForm();
        });
    } else {
        console.log('没有token，显示登录表单');
        // 没有token，显示登录表单
        showLoginForm();
    }
    
    // 隐藏添加默认授权码按钮
    const addDefaultBtn = document.querySelector('button');
    if (addDefaultBtn && addDefaultBtn.textContent.includes('添加默认授权码')) {
        addDefaultBtn.style.display = 'none';
    }

    // 新增：搜索与分页相关变量
    const searchInput = document.getElementById('searchInput');
    const paginationDiv = document.getElementById('pagination');
    let filteredLicenses = {};
    let currentPage = 1;
    const PAGE_SIZE = 10;

    // 监听搜索输入
    if (searchInput) {
        searchInput.addEventListener('input', () => {
            currentPage = 1;
            renderLicensesWithSearchAndPage();
        });
    }

    // 渲染带搜索和分页的授权码
    function renderLicensesWithSearchAndPage() {
        const keyword = searchInput ? searchInput.value.trim().toLowerCase() : '';
        // 过滤
        filteredLicenses = {};
        for (const key in allLicenses) {
            let license = allLicenses[key];
            if (typeof license === 'string') {
                try { license = JSON.parse(license); } catch { continue; }
            }
            const hotelName = (license.hotelName || '').toLowerCase();
            if (key.toLowerCase().includes(keyword) || hotelName.includes(keyword)) {
                filteredLicenses[key] = license;
            }
        }
        // 分页
        const keys = Object.keys(filteredLicenses);
        const total = keys.length;
        const totalPages = Math.ceil(total / PAGE_SIZE) || 1;
        if (currentPage > totalPages) currentPage = totalPages;
        const startIdx = (currentPage - 1) * PAGE_SIZE;
        const pageKeys = keys.slice(startIdx, startIdx + PAGE_SIZE);
        // 构造分页数据
        const pageLicenses = {};
        for (const k of pageKeys) pageLicenses[k] = filteredLicenses[k];
        renderLicenses(pageLicenses);
        renderPagination(totalPages);
    }

    // 渲染分页栏
    function renderPagination(totalPages) {
        paginationDiv.innerHTML = '';
        if (totalPages <= 1) return;
        let start = Math.max(1, currentPage - 2);
        let end = Math.min(totalPages, start + 4);
        if (end - start < 4) start = Math.max(1, end - 4);
        // 上一页按钮
        const prevBtn = document.createElement('button');
        prevBtn.textContent = '«';
        prevBtn.disabled = currentPage === 1;
        prevBtn.className = 'page-btn';
        prevBtn.onclick = () => { if (currentPage > 1) { currentPage--; renderLicensesWithSearchAndPage(); } };
        paginationDiv.appendChild(prevBtn);
        // 数字页码
        for (let i = start; i <= end; i++) {
            const btn = document.createElement('button');
            btn.textContent = i;
            btn.className = 'page-btn' + (i === currentPage ? ' active' : '');
            btn.onclick = () => { currentPage = i; renderLicensesWithSearchAndPage(); };
            paginationDiv.appendChild(btn);
        }
        // 下一页按钮
        const nextBtn = document.createElement('button');
        nextBtn.textContent = '»';
        nextBtn.disabled = currentPage === totalPages;
        nextBtn.className = 'page-btn';
        nextBtn.onclick = () => { if (currentPage < totalPages) { currentPage++; renderLicensesWithSearchAndPage(); } };
        paginationDiv.appendChild(nextBtn);
    }

    // 新增：初始渲染
    if (searchInput && paginationDiv) {
        renderLicensesWithSearchAndPage();
    }

    // 账号管理相关
    const accountCard = document.getElementById('accountCard');

    // 重置密码弹窗
    function showResetPwdDialog(username, callback) {
        const dialog = document.createElement('div');
        dialog.style.position = 'fixed';
        dialog.style.left = '0';
        dialog.style.top = '0';
        dialog.style.width = '100vw';
        dialog.style.height = '100vh';
        dialog.style.background = 'rgba(0,0,0,0.3)';
        dialog.style.display = 'flex';
        dialog.style.alignItems = 'center';
        dialog.style.justifyContent = 'center';
        dialog.innerHTML = `<div style="background:#fff;padding:24px 32px;border-radius:8px;min-width:260px;box-shadow:0 2px 12px #0002;">
            <h3 style="margin-bottom:12px;">重置密码 - ${username}</h3>
            <input type="password" id="resetPwdInput" placeholder="新密码" style="width:100%;padding:8px;margin-bottom:12px;">
            <div style="text-align:right;">
                <button id="resetPwdCancel">取消</button>
                <button id="resetPwdOk" style="margin-left:8px;">确定</button>
            </div>
            <p id="resetPwdMsg" style="color:#d33;margin:8px 0 0 0;"></p>
        </div>`;
        document.body.appendChild(dialog);
        dialog.querySelector('#resetPwdCancel').onclick = () => document.body.removeChild(dialog);
        dialog.querySelector('#resetPwdOk').onclick = async () => {
            const pwd = dialog.querySelector('#resetPwdInput').value.trim();
            if (!pwd) {
                dialog.querySelector('#resetPwdMsg').textContent = '请输入新密码';
                return;
            }
            dialog.querySelector('#resetPwdOk').disabled = true;
            try {
                await callback(pwd);
                alert('密码重置成功！');
                document.body.removeChild(dialog);
            } catch (e) {
                dialog.querySelector('#resetPwdMsg').textContent = e.message || '重置失败';
                dialog.querySelector('#resetPwdOk').disabled = false;
            }
        };
    }

    // 仅管理员可见账号管理卡片
    function updateAccountCardVisibility() {
        const accountCard = document.getElementById('accountCard');
        if (!accountCard) {
            console.error('未找到账号管理卡片元素');
            return;
        }
        
        if (currentUser && currentUser.role === 'admin') {
            console.log('当前用户是管理员，显示账号管理卡片');
            accountCard.style.display = 'block';
            // 立即获取账号列表
            fetchAccounts();
        } else {
            console.log('当前用户不是管理员，隐藏账号管理卡片');
            accountCard.style.display = 'none';
        }
    }
    // 渲染账号表
    async function fetchAccounts() {
        if (!currentUser || currentUser.role !== 'admin') {
            return;
        }
        try {
            console.log('开始获取账号列表...');
            const resp = await apiFetch(`${apiBaseUrl}/accounts`);
            if (!resp.ok) throw new Error('获取账号列表失败');

            const data = await resp.json();
            console.log('获取到的账号数据:', data.accounts);
            renderAccountsTable(data.accounts || []);
        } catch (error) {
            console.error('获取账号列表失败:', error);
            if(accountsTable) {
                accountsTable.innerHTML = '<tr><td colspan="5" style="text-align:center;">加载合作伙伴列表失败</td></tr>';
            }
        }
    }
    
    // [新增] 渲染合作伙伴账号表格的函数
    function renderAccountsTable(accounts) {
        if (!accountsTable) return;

        accountsTable.innerHTML = '';

        if (!accounts || accounts.length === 0) {
            accountsTable.innerHTML = '<tr><td colspan="5" style="text-align:center;">暂无合作伙伴数据</td></tr>';
            return;
        }

        accounts.forEach(acc => {
            const tr = document.createElement('tr');
            let ops = '';
            // 管理员账号不能被操作
            if (acc.username !== 'admin') {
                ops = `
                    <button class="btn btn-sm btn-danger del-account-btn" data-username="${acc.username}">删除</button>
                    <button class="btn btn-sm btn-warning reset-pwd-btn" data-username="${acc.username}">重置密码</button>
                `;
            }
            tr.innerHTML = `
                <td>${acc.username}</td>
                <td>${acc.name}</td>
                <td>${acc.role}</td>
                <td>${acc.createdAt ? new Date(acc.createdAt).toLocaleDateString() : '—'}</td>
                <td>${ops}</td>
            `;
            accountsTable.appendChild(tr);
        });
    }

    // 添加账号
    addAccountForm.onsubmit = async function(e) {
        e.preventDefault();
        console.log('提交添加账号表单');
        
        // 获取表单数据
        const username = newAccountUsername.value.trim();
        const name = newAccountName.value.trim();
        const password = newAccountPassword.value;
        
        // 表单验证
        if (!username) {
            alert('请输入用户名');
            newAccountUsername.focus();
            return;
        }
        
        if (!name) {
            alert('请输入合作伙伴名称');
            newAccountName.focus();
            return;
        }
        
        if (!password) {
            alert('请输入密码');
            newAccountPassword.focus();
            return;
        }
        
        try {
            // 显示加载状态
            const submitBtn = addAccountForm.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            submitBtn.disabled = true;
            submitBtn.textContent = '添加中...';
            
            console.log('发送添加账号请求:', { username, name });
            const resp = await apiFetch(`${apiBaseUrl}/accounts`, {
                method: 'POST',
                body: JSON.stringify({ username, name, password })
            });
            
            const data = await resp.json();
            
            if (!resp.ok) {
                console.error('添加账号失败:', data);
                alert(data.error || '添加失败');
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
                return;
            }
            
            console.log('添加账号成功:', data);
            alert('添加成功');
            addAccountForm.reset(); // 使用标准的reset()方法
            fetchAccounts();
        } catch (error) {
            console.error('添加账号出错:', error);
            alert('添加账号时发生错误，请稍后重试');
        } finally {
            // 恢复按钮状态
            const submitBtn = addAccountForm.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.textContent = '添加合作伙伴';
            }
        }
    };
    // 账号表按钮事件
    accountsTable.addEventListener('click', async (event) => {
        const target = event.target;

        // [修正] 删除账号按钮的逻辑
        if (target.classList.contains('del-account-btn')) {
            const username = target.dataset.username;
            if (username && confirm(`确认删除合作伙伴 ${username} 吗？`)) {
                try {
                    // URL中包含用户名，不再使用body
                    const resp = await apiFetch(`${apiBaseUrl}/accounts/${username}`, {
                        method: 'DELETE'
                    });
                    const result = await resp.json();
                    if (!resp.ok) throw new Error(result.message);
                    alert('删除成功');
                    fetchAccounts(); // 重新加载列表
                } catch (error) {
                    alert(`删除失败: ${error.message}`);
                }
            }
        }

        // [修正] 重置密码按钮的逻辑
        if (target.classList.contains('reset-pwd-btn')) {
            const username = target.dataset.username;
            showResetPwdDialog(username, async (newPassword) => {
                try {
                    const resp = await apiFetch(`${apiBaseUrl}/reset-password`, {
                        method: 'POST',
                        body: JSON.stringify({ username, newPassword })
                    });
                    const result = await resp.json();
                    if (!resp.ok) throw new Error(result.message);
                    alert(result.message);
                    return true; // 表示成功，可以关闭弹窗
                } catch (error) {
                    alert(`重置密码失败: ${error.message}`);
                    return false; // 表示失败
                }
            });
        }
    });

    // 非admin右上角重置密码按钮
    function renderSelfResetPwdBtn() {
        if (!currentUser || currentUser.role === 'admin') return;
        let btn = document.getElementById('selfResetPwdBtn');
        if (!btn) {
            btn = document.createElement('button');
            btn.id = 'selfResetPwdBtn';
            btn.textContent = '重置密码';
            btn.style.position = 'absolute';
            btn.style.top = '18px';
            btn.style.right = '32px';
            btn.style.zIndex = '10';
            document.body.appendChild(btn);
        }
        btn.onclick = () => {
            showResetPwdDialog(currentUser.username, async (newPwd) => {
                try {
                    console.log('发送重置自己密码请求');
                    const resp = await apiFetch(`${apiBaseUrl}/reset-password`, {
                        method: 'POST',
                        body: JSON.stringify({ username: currentUser.username, newPassword: newPwd })
                    });
                    
                    const data = await resp.json();
                    
                    if (!resp.ok) {
                        console.error('重置密码失败:', data);
                        throw new Error(data.error || '重置失败');
                    }
                    
                    console.log('重置密码成功:', data);
                } catch (error) {
                    console.error('重置密码出错:', error);
                    throw error;
                }
            });
        };
    }

    // 日志相关
    const logsCard = document.getElementById('logsCard');
    const logsTable = document.getElementById('logsTable').querySelector('tbody');
    const logsPagination = document.getElementById('logsPagination');
    let logsPage = 1;
    const LOGS_PAGE_SIZE = 20;

    async function fetchLogs(page = 1) {
        const resp = await apiFetch(`${apiBaseUrl}/logs?page=${page}&pageSize=${LOGS_PAGE_SIZE}`, { headers: getAuthHeaders() });
        const data = await resp.json();
        renderLogsTable(data.logs || []);
        // 简单分页（不查总数，前后翻页）
        logsPagination.innerHTML = '';
        const prevBtn = document.createElement('button');
        prevBtn.textContent = '«';
        prevBtn.disabled = page === 1;
        prevBtn.onclick = () => { if (logsPage > 1) { logsPage--; fetchLogs(logsPage); } };
        logsPagination.appendChild(prevBtn);
        const nextBtn = document.createElement('button');
        nextBtn.textContent = '»';
        nextBtn.onclick = () => { logsPage++; fetchLogs(logsPage); };
        logsPagination.appendChild(nextBtn);
    }
    function renderLogsTable(logs) {
        logsTable.innerHTML = '';
        if (!logs.length) {
            logsTable.innerHTML = '<tr><td colspan="4" style="text-align:center;">暂无日志</td></tr>';
            return;
        }
        logs.forEach(log => {
            const tr = document.createElement('tr');
            tr.innerHTML = `<td>${log.time.replace('T',' ').slice(0,19)}</td><td>${log.username} (${log.role})</td><td>${log.type}</td><td>${log.detail}</td>`;
            logsTable.appendChild(tr);
        });
    }
    // 管理员登录后自动显示日志卡片，代理商可手动切换
    function showLogsCard(show) {
        logsCard.style.display = show ? '' : 'none';
        if (show) {
            logsPage = 1;
            fetchLogs(logsPage);
        }
    }

    // 新增：管理员的合作伙伴统计看板
    function renderPartnerStatsCard(isAdmin) {
        // 检查是否已存在看板
        let partnerStatsCard = document.getElementById('partnerStatsCard');
        
        // 如果不是管理员或看板已存在且需要移除
        if (!isAdmin) {
            if (partnerStatsCard) {
                partnerStatsCard.remove();
            }
            return;
        }
        
        // 为管理员创建或更新看板
        if (!partnerStatsCard) {
            partnerStatsCard = document.createElement('div');
            partnerStatsCard.id = 'partnerStatsCard';
            partnerStatsCard.className = 'card';
            
            // 将看板插入到dashboard之后
            const dashboard = document.getElementById('dashboard');
            if (dashboard && dashboard.nextSibling) {
                dashboard.parentNode.insertBefore(partnerStatsCard, dashboard.nextSibling);
            } else if (dashboard) {
                dashboard.parentNode.appendChild(partnerStatsCard);
            }
        }
        
        // 设置看板内容
        partnerStatsCard.innerHTML = `
            <h2><i class="fas fa-chart-pie"></i> 合作伙伴数据看板</h2>
            <div class="partner-stats-controls">
                <div class="stats-period-selector">
                    <label><i class="fas fa-calendar-alt"></i> 统计周期：</label>
                    <select id="statsPeriod">
                        <option value="day">今日</option>
                        <option value="week">本周</option>
                        <option value="month" selected>本月</option>
                        <option value="year">本年</option>
                        <option value="all">全部</option>
                    </select>
                </div>
            </div>
            <div class="table-responsive">
                <table id="partnerStatsTable">
                    <thead>
                        <tr>
                            <th><i class="fas fa-user-tie"></i> 合作伙伴</th>
                            <th><i class="fas fa-key"></i> 总授权数</th>
                            <th><i class="fas fa-check-circle"></i> 有效授权</th>
                            <th><i class="fas fa-bolt"></i> 本期激活</th>
                            <th><i class="fas fa-chart-line"></i> 趋势</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr><td colspan="5" style="text-align:center;">加载中...</td></tr>
                    </tbody>
                </table>
            </div>
        `;
        
        // 添加周期选择事件
        const periodSelector = document.getElementById('statsPeriod');
        if (periodSelector) {
            periodSelector.addEventListener('change', () => {
                fetchPartnerStats(periodSelector.value);
            });
            
            // 初始加载数据
            fetchPartnerStats(periodSelector.value);
        }
    }
    
    // 获取合作伙伴统计数据
    async function fetchPartnerStats(period = 'month') {
        try {
            console.log(`获取合作伙伴统计数据，周期: ${period}，URL: ${apiBaseUrl}/dashboard?period=${period}`);
            const resp = await apiFetch(`${apiBaseUrl}/dashboard?period=${period}`);
            
            if (!resp.ok) {
                console.error('获取合作伙伴统计数据失败:', resp.status, resp.statusText);
                throw new Error(`获取数据失败: ${resp.status} ${resp.statusText}`);
            }
            
            const data = await resp.json();
            console.log('获取到的合作伙伴统计数据:', data);
            
            // 更新表格
            const tbody = document.querySelector('#partnerStatsTable tbody');
            if (!tbody) {
                console.error('找不到合作伙伴统计表格元素');
                return;
            }
            
            if (!data.agentStats || data.agentStats.length === 0) {
                tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;">暂无数据</td></tr>';
                return;
            }
            
            tbody.innerHTML = '';
            data.agentStats.forEach(agent => {
                const row = document.createElement('tr');
                
                // 简单的趋势图标
                const trendIcon = agent.trend > 0 ? '<i class="fas fa-arrow-up" style="color:#27ae60"></i>' : 
                                 agent.trend < 0 ? '<i class="fas fa-arrow-down" style="color:#e74c3c"></i>' : 
                                 '<i class="fas fa-equals" style="color:#7f8c8d"></i>';
                
                row.innerHTML = `
                    <td>${agent.name || 'unknown'} (${agent.username || 'unknown'})</td>
                    <td>${agent.licenseCount || 0}</td>
                    <td>${agent.activeCount || 0}</td>
                    <td>${agent.todayActivations || 0}</td>
                    <td>${trendIcon}</td>
                `;
                tbody.appendChild(row);
            });
            
        } catch (error) {
            console.error('获取合作伙伴统计数据失败:', error);
            const tbody = document.querySelector('#partnerStatsTable tbody');
            if (tbody) {
                tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;">数据加载失败: ${error.message}</td></tr>`;
            }
        }
    }

    // 添加默认JD-FIRST-KEY授权码
    async function addDefaultLicense() {
        if (!isAuthenticated) {
            alert('请先登录');
            showLoginForm();
            return;
            }
        
        try {
            const today = new Date();
            const oneYearLater = new Date(today);
            oneYearLater.setFullYear(today.getFullYear() + 1);
            
            const licenseData = {
                licenseKey: 'JD-FIRST-KEY',
                hotelName: '默认酒店',
                startDate: today.toISOString().split('T')[0],
                expiryDate: oneYearLater.toISOString().split('T')[0]
            };
            
            console.log('添加默认授权码:', licenseData);
            const response = await apiFetch(`${apiBaseUrl}/licenses`, {
                method: 'POST',
                body: JSON.stringify(licenseData)
            });
            
            if (response.status === 401) {
                isAuthenticated = false;
                showLoginForm();
                return;
            }
            
            if (!response.ok) {
                console.error('添加默认授权码失败:', response.status);
                alert('添加默认授权码失败');
                return;
            }
            
            console.log('默认授权码添加成功');
            alert('默认授权码添加成功');
            fetchLicenses();
        } catch (error) {
            console.error('添加默认授权码出错:', error);
            alert('添加默认授权码出错: ' + error.message);
        }
    }
    
    // 旧版登录函数，保留兼容性
    async function login(password) {
        try {
            const response = await apiFetch('/licenses', {
                method: 'GET',
                headers: { 'Authorization': `Basic ${btoa(`:${password}`)}` }
            });
            
            if (response.status === 401) {
                document.getElementById('loginMessage').textContent = '密码错误，请重试';
                return false;
            }
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            return true;
        } catch (error) {
            console.error('Login error:', error);
            document.getElementById('loginMessage').textContent = '登录时发生错误，请重试';
            return false;
        }
    }

    // 添加登录按钮事件监听
    function setupLoginForm() {
        if (loginContainer && loginBtn && loginPassword) {
            // 新版登录表单
            loginBtn.addEventListener('click', handleLogin);
            loginPassword.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    handleLogin();
                }
            });
            return;
        }
        
        // 等待旧版登录表单创建完成
        setTimeout(() => {
            // 旧版登录兼容
            const oldLoginBtn = document.getElementById('loginBtn');
            const passwordInput = document.getElementById('adminPassword');
            
            if (oldLoginBtn && passwordInput) {
                oldLoginBtn.addEventListener('click', handleLogin);
                passwordInput.addEventListener('keypress', (e) => {
                    if (e.key === 'Enter') {
                        e.preventDefault();
                        handleLogin();
                    }
                });
            }
        }, 100);
    }

    // 根据用户角色，更新UI元素的可见性
    function updateUIVisibility() {
        const isAdmin = currentUser && currentUser.role === 'admin';
        const accountsCard = document.getElementById('accountsCard');
        const logsCard = document.getElementById('logsCard');
        
        if (accountsCard) {
            accountsCard.style.display = isAdmin ? 'block' : 'none';
        }
        if (logsCard) {
            logsCard.style.display = isAdmin ? 'block' : 'none';
        }
    }

    // 最终入口函数
    checkLoginStatus();
}); 